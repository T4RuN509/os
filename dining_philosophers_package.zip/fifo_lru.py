def fifo_page_replacement(pages, capacity):
    memory = []
    page_faults = 0
    for page in pages:
        if page not in memory:
            if len(memory) < capacity:
                memory.append(page)
            else:
                memory.pop(0)
                memory.append(page)
            page_faults += 1
        print(f"Page {page} -> Memory: {memory}")
    print("\nTotal Page Faults (FIFO):", page_faults)

def lru_page_replacement(pages, capacity):
    memory = []
    page_faults = 0
    for page in pages:
        if page in memory:
            memory.remove(page)
            memory.append(page)
        else:
            if len(memory) < capacity:
                memory.append(page)
            else:
                memory.pop(0)
                memory.append(page)
            page_faults += 1
        print(f"Page {page} -> Memory: {memory}")
    print("\nTotal Page Faults (LRU):", page_faults)

pages = [1, 3, 0, 3, 5, 6]
capacity = 3
fifo_page_replacement(pages, capacity)
lru_page_replacement(pages, capacity)
