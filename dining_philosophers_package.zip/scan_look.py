def scan_disk_scheduling(requests, head, direction, disk_size):
    requests.sort()
    seek_sequence = []
    seek_count = 0
    if direction == "left":
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]
        left.sort(reverse=True)
        for r in left:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
        seek_count += head
        head = 0
        for r in right:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
    elif direction == "right":
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]
        right.sort()
        for r in right:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
        seek_count += abs(disk_size - 1 - head)
        head = disk_size - 1
        left.sort(reverse=True)
        for r in left:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
    print("Seek Sequence (SCAN):", seek_sequence)
    print("Total Seek Operations:", seek_count)

def look_disk_scheduling(requests, head, direction):
    requests.sort()
    seek_sequence = []
    seek_count = 0
    if direction == "left":
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]
        left.sort(reverse=True)
        for r in left:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
        for r in right:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
    elif direction == "right":
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]
        right.sort()
        for r in right:
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
        for r in reversed(left):
            seek_sequence.append(r)
            seek_count += abs(head - r)
            head = r
    print("Seek Sequence (LOOK):", seek_sequence)
    print("Total Seek Operations:", seek_count)

requests = [82, 170, 43, 140, 24, 16, 190]
head = 50
disk_size = 200
direction = "right"
scan_disk_scheduling(requests, head, direction, disk_size)
look_disk_scheduling(requests, head, direction)
