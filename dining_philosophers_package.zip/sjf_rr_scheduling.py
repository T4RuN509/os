def sjf_scheduling(processes):
    n = len(processes)
    processes.sort(key=lambda x: x[1])  # Sort by burst time
    waiting_time = [0] * n
    turnaround_time = [0] * n

    for i in range(1, n):
        waiting_time[i] = waiting_time[i-1] + processes[i-1][1]

    for i in range(n):
        turnaround_time[i] = waiting_time[i] + processes[i][1]

    print("SJF Scheduling:")
    print("PID\tBT\tWT\tTAT")
    for i in range(n):
        print(f"{processes[i][0]}\t{processes[i][1]}\t{waiting_time[i]}\t{turnaround_time[i]}")
    print()


def round_robin_scheduling(processes, quantum):
    n = len(processes)
    remaining_bt = [bt for pid, bt in processes]
    waiting_time = [0] * n
    t = 0
    while True:
        done = True
        for i in range(n):
            if remaining_bt[i] > 0:
                done = False
                if remaining_bt[i] > quantum:
                    t += quantum
                    remaining_bt[i] -= quantum
                else:
                    t += remaining_bt[i]
                    waiting_time[i] = t - processes[i][1]
                    remaining_bt[i] = 0
        if done:
            break

    turnaround_time = [processes[i][1] + waiting_time[i] for i in range(n)]

    print("Round Robin Scheduling:")
    print("PID\tBT\tWT\tTAT")
    for i in range(n):
        print(f"{processes[i][0]}\t{processes[i][1]}\t{waiting_time[i]}\t{turnaround_time[i]}")
    print()


# Example data
processes = [(1, 6), (2, 8), (3, 7), (4, 3)]
quantum = 4

sjf_scheduling(processes.copy())
round_robin_scheduling(processes.copy(), quantum)
