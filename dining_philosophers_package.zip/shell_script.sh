#!/bin/bash
echo "Hello, World!"

# If condition
if [ $1 -gt 10 ]; then
  echo "Greater than 10"
else
  echo "10 or less"
fi

# For loop
for i in 1 2 3
do
  echo "Loop $i"
done

# While loop
count=1
while [ $count -le 5 ]
do
  echo "Count is $count"
  ((count++))
done
