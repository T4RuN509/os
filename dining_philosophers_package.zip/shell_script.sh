#!/bin/bash
echo "Hello, World!"

# If condition
if [ $1 -gt 10 ]; then
  echo "Greater than 10"
else
  echo "10 or less"
fi

# For loop
for i in 1 2 3
do
  echo "Loop $i"
done

# While loop
count=1
while [ $count -le 5 ]
do
  echo "Count is $count"
  ((count++))
done

# System Info

echo "===== a) OS Version, Release Number, Kernel Version ====="
uname -a
echo

echo "===== b) Top 10 Processes (by CPU usage) ====="
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 11
echo

echo "===== c) Process with Highest Memory Usage ====="
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head -n 6
echo

echo "===== d) Logged in User and Log Name ====="
echo "User: $USER"
echo "Logname: $LOGNAME"
echo

echo "===== e) Shell, Home Directory, OS Type, PATH, Working Directory ====="
echo "Current Shell: $SHELL"
echo "Home Directory: $HOME"
echo "OS Type: $(uname)"
echo "PATH: $PATH"
echo "Current Working Directory: $(pwd)"
