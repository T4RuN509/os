# XOR function to perform bitwise XOR operation
def xor(a, b):
    return ''.join(['0' if i == j else '1' for i, j in zip(a, b)])

# Function to perform modulo-2 division (used for CRC)
def mod2div(dividend, divisor):
    # 'pick' is the length of the divisor
    pick = len(divisor)
    tmp = dividend[:pick]  # Take the first 'pick' bits of the dividend
    while pick < len(dividend):  # Loop until the whole dividend is processed
        # If the leftmost bit of tmp is 1, XOR with divisor, otherwise XOR with 0's
        tmp = xor(divisor, tmp) + dividend[pick] if tmp[0] == '1' else xor('0' * pick, tmp) + dividend[pick]
        tmp = tmp[1:]  # Shift the window by removing the first bit
        pick += 1
    # Return the remainder after modulo-2 division
    return xor(divisor, tmp)[1:] if tmp[0] == '1' else xor('0' * pick, tmp)[1:]

# Function to encode data using CRC
def encode_crc(data, key):
    l_key = len(key)  # Length of the generator polynomial (key)
    # Append '0's to the data to match the length of the key-1
    appended_data = data + '0'*(l_key - 1)
    # Get the remainder after performing modulo-2 division
    remainder = mod2div(appended_data, key)
    # Return the original data concatenated with the remainder (CRC code)
    return data + remainder

# Function to calculate the Hamming Code for error detection
def calc_hamming_code(data):
    m = len(data)  # Length of the input data
    r = 0  # Number of redundancy bits needed
    # Calculate the minimum number of parity bits required
    while (2**r) < (m + r + 1):
        r += 1

    # Initialize the result array with '0's
    result = ['0'] * (m + r + 1)
    j = 0
    for i in range(1, len(result)):
        # Place parity bits at positions that are powers of 2 (1, 2, 4, 8, ...)
        if i == 2**j:
            j += 1
        else:
            result[i] = data[-1]  # Fill other positions with data bits
            data = data[:-1]

    # Calculate the parity bits' values based on the Hamming Code rules
    for i in range(r):
        idx = 2**i
        val = 0
        for j in range(1, len(result)):
            if j & idx:
                val ^= int(result[j])  # XOR all bits covered by this parity bit
        result[idx] = str(val)  # Set the parity bit value

    # Return the Hamming code (excluding the first bit) in reversed order to match the data order
    return ''.join(result[1:])[::-1]

# Main Program
print("Choose the method:")
print("1. CRC")
print("2. Hamming Code")
choice = int(input("Enter 1 or 2: "))  # Prompt the user to choose CRC or Hamming Code

if choice == 1:  # If the user chooses CRC
    data = input("Enter binary data: ")  # Input binary data
    key = input("Enter generator polynomial (binary): ")  # Input generator polynomial
    crc = encode_crc(data, key)  # Get the CRC encoded data
    print("CRC encoded data:", crc)  # Output the CRC encoded data

elif choice == 2:  # If the user chooses Hamming Code
    data = input("Enter binary data: ")  # Input binary data
    hamming = calc_hamming_code(data[::-1])  # Reverse the input for indexing, then calculate Hamming code
    print("Hamming encoded data:", hamming)  # Output the Hamming encoded data

else:  # Invalid choice
    print("Invalid choice")
















# client
# import socket

# # Create a client socket
# client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# # Connect to the server
# client_socket.connect(('localhost', 12345))

# # Send data to the server
# client_socket.send("Hello from client!".encode())

# # Receive response from the server
# data = client_socket.recv(1024)
# print(f"Received from server: {data.decode()}")

# # Close the socket
# client_socket.close()


# SERVER
# import socket

# # Create a server socket AF_INET stands for Address Family 
# # - Internet. It specifies the type of addresses the socket will use for communication.
# server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# # Bind the server to a specific address and port
# server_socket.bind(('localhost', 12345))

# # Listen for incoming connections
# server_socket.listen(5)
# print("Server is listening for connections...")

# # Accept incoming connection
# client_socket, client_address = server_socket.accept()
# print(f"Connection established with {client_address}")

# # Receive data from client
# data = client_socket.recv(1024)
# print(f"Received from client: {data.decode()}")

# # Send data back to client
# client_socket.send("Hello from server!".encode())

# # Close the connection
# client_socket.close()
# server_socket.close()
