import socket

# Create a client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect(('localhost', 12345))

# Send data to the server
client_socket.send("Hello from client!".encode())

# Receive response from the server
data = client_socket.recv(1024)
print(f"Received from server: {data.decode()}")

# Close the socket
client_socket.close()



# Server
# import socket

# # Create a server socket AF_INET stands for Address Family 
# # - Internet. It specifies the type of addresses the socket will use for communication.
# server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# # Bind the server to a specific address and port
# server_socket.bind(('localhost', 12345))

# # Listen for incoming connections
# server_socket.listen(5)
# print("Server is listening for connections...")

# # Accept incoming connection
# client_socket, client_address = server_socket.accept()
# print(f"Connection established with {client_address}")

# # Receive data from client
# data = client_socket.recv(1024)
# print(f"Received from client: {data.decode()}")

# # Send data back to client
# client_socket.send("Hello from server!".encode())

# # Close the connection
# client_socket.close()
# server_socket.close()
